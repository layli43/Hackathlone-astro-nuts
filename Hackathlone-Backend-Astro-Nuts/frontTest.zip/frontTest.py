import requests

response = requests.get("http://127.0.0.1:8080/asteroids?start_date=2025-10-01&end_date=2025-10-07 ")
#response = requests.get("http://127.0.0.1:8000/ai/generalSummary")
print(response)
